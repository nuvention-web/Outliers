var mongoose = require('mongoose');


module.exports = mongoose.model('Flight', {

//	msg: String,
	name: String,
//	date: String



});